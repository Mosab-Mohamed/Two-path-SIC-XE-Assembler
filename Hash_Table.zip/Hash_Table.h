#ifndef HASH_TABLE_H
#define HASH_TABLE_H
#include <iostream>
#include <bits/stdc++.h>

using namespace std;

class Hash_Table
{
    public:
        Hash_Table();
        int search_form(string);
    protected:
    private:
};

#endif // HASH_TABLE_H
