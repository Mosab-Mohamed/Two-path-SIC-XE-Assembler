#include "Hash_Table.h"
#include <iostream>
#include <bits/stdc++.h>

using namespace std;

Hash_Table::Hash_Table()
{

}

int Hash_Table::search_form(string)
{

}
